#computer-network #application-layer 

# Concepts
- ==Host-to-host== connection via ==sockets== (transport layer).
- Packets are called ==messages==.
# Requirements for transport layer
![](Pasted%20image%2020240512091822.png)
==Real-time apps== may be ==loss-tolerant==, but other like file or Web documents is more sensitive.

![](Pasted%20image%2020240512092036.png)
==Real-time apps== may employ UDP, ignores reliable data transfer service from TCP.

---
# References
1. Computer Networking  A Top-Down Approach, Global Edition, 8th Edition - James F. Kurose - Keith W. Ross.