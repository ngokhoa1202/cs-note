#email  #application-layer #client-server  #protocol #computer-network 

- Stands for ==Simple Mail Transfer Protocol==
- Is a ==push protocol==: 
	- server or sender initiates connection and pushes data to client/server ==without explicit requests==.
- Default port: 25.

