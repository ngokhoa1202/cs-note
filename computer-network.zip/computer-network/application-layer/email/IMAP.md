#email #computer-network #application-layer 

- Stands for ==Internet Message Access Protocol==.
- Default TCP port: 143.
- Provides stronger authentication than [POP3](POP3.md) 
- 