#email #computer-network #application-layer #protocol #client-server 

- Stands for ==Post Office Protocol==.
- Allows mail client to download mails from a mail server (MTA).
- Default TCP port: 110.
- Provides authentication, which can be stored locally
	- username:
	- password