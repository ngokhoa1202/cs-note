#application-layer #email #computer-network #protocol 

- Stands for ==Multiplepurpose Internet Mail Extension==.
- Support many content formats and encodings.

# Header
- MIME Version: 1.0
- ==Content-Type==:
- ==Content-Transfer-Encoding==: type of encodings to encode body.
- Content-ID: 
- Content-Description:
- ![](Pasted%20image%2020240514160525.png)
- ![](Pasted%20image%2020240514160744.png)
- 