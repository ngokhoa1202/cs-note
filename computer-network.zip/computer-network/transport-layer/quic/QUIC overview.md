#computer-network  #transport-layer #protocol #udp #ongoing 

- Stands for ==Quick UDP Internet Connection==.
- Incorporated with ==HTTP/3.==
- Based on UDP [UDP](UDP.md)
- Incorporate TLSv1.3
# Characteristics
- Connection-oriented.
- Secure.
- Stream.
- Reliable data transfer, congestion control like TCP.
- ![](Pasted%20image%2020240519105322.png)
- 