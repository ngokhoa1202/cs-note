#transport-layer  #computer-network 

- Packets are called ==segments==.
- Communication between ==processes==.
# Socket
- IP address + port.
# Multiplexing
- ==Gather== data from sockets, add transport header and forwards to network layer.
# Demultiplexing
- Use header to ==forward data to correct socket==.
- ![](Pasted%20image%2020240514203949.png)

# TCP
[TCP](TCP.md)
# UDP
[UDP](UDP.md)

