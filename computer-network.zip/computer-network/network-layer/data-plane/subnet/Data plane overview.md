#computer-network  #network-layer #data-plane 

# Service
- ==Forward== packets from inbound port to correct outbound port.
- Local, ==per-router== function.
# Router
[Router](Router.md)

## Buffer management
- [Buffer management](Buffer%20management.md)
## Packet scheduling
- FIFO.
- Priority Queuing.
- Round Robin $\Rightarrow$ Weighted Fair Queuing.
# IP Address
- [IPv4](IPv4.md)




