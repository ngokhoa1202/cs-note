#nat #network-layer #computer-network #data-plane #subnet 

- Stands for ==Network address translation==.

# Principle
- All hosts in a local network ==shares only one IP address==,
- Maps ==internal host's IP address to external IP address== when packet is going out to the Internet.
- ![](Pasted%20image%2020240522152039.png)
- Router stores a NAT translation table containing ==WAN-to-LAN address records==. (aka Internet $\to$ Intranet).

---
# References
1. 
