#network-layer #computer-network #router #control-plane #data-plane 


- "==Best-effort==" service.
- Network ==core== $\Rightarrow$ mainly works with ==router==.
- Provide service:
	- Routing.
	- Forwarding.
- Packet is called ==datagram==.
# Data plane
- [Data plane overview](Data%20plane%20overview.md)
- Forwarding: move packet to ==correct link interface==.
# Control plane
- Routing: determine packet's route.
- 
---
# References
1. Computer Networking  A Top-Down Approach, Global Edition, 8th Edition - James F. Kurose - Keith W. Ross.
	1. Chapter 4: Network layer - The Data Plane.
	2. Chapter 5: Network Layer - The Control Plane.
