#routing #algorithm #network-layer 
# Principle
- Choose local gateway that has ==least intra-domain cost==.