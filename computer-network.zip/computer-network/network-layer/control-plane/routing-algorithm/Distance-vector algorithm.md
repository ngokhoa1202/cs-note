#routing #algorithm #graph-theory #computer-network #network-layer #control-plane 

# Algorithm
## Requirement
- Graph $G=(V,E)$ where $V$: set of routers and $E$: set of links.
## Solution
[Bellman-Ford algorithm](Bellman-Ford%20algorithm.md)
