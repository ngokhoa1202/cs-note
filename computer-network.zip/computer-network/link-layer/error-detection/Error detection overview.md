#link-layer #computer-network 

# Parity bit

- Can use two-dimensional parity.
# Internet checksum

# Cyclic Redundancy Check

