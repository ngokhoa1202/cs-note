#mac #taking-turns #computer-network #link-layer #taking-turns 
# Principle
- Exchange tokens among nodes.
- Transmit frames only when holding token
- ![600x400](Pasted%20image%2020240520151316.png)
# Advantage
- High throughput.
- Decentralized.
# Disadvantage
- Token overhead.
- One node crash leads to system failure.