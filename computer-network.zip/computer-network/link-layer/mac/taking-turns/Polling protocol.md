#mac #taking-turns #link-layer #computer-network #link-layer 

# Principle
- In theory, best protocol, but...
- Requires ==a master node to poll== each other node according to round-robin policy.
- ![400x300](Pasted%20image%2020240520151147.png)
# Advantage
- Polling delay.
- A single point of failure.
# Examples
- Bluetooth.
