#vlan #lan #protocol #link-layer  #computer-network 

- Defined in ==IEEE 802.1Q==

# VLAN Frame Format
- Extended from [Ethernet frame format](Ethernet.md#Ethernet%20frame%20format)
- Add ==VLAN tag== field.
- ![](Pasted%20image%2020240521131456.png)
- 