#lan #computer-network #link-layer 

- Stands for Virtual Local Area Network - ==Virtual LAN==.
- Define multiple virtual LAN ==over a single physical LAN==.
# VLAN Frame
[VLAN Frame](VLAN%20Frame.md)
# Port-based VLAN
- Define specific port ranges for each VLAN.
- ![](Pasted%20image%2020240521130410.png)
-  ==Router== performs routing between VLANs. 
# VLAN spanning multiple switches
- Use a ==trunk port== on each switch, which transmitting frames between two VLANs:
	- Employs [802.1Q Frame](VLAN%20Frame.md).
- ![](Pasted%20image%2020240521131206.png)
- 