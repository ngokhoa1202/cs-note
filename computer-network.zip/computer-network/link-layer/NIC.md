#hardware #computer-network #link-layer #nic 

- Stands for ==Network Interface Card==.
- Installed in each computer to help it ==connect to network==.

# Basic structure
- ![](Pasted%20image%2020240520133546.png)
- Can be made on board.
- Attached to host's ==buses== and connected to CPU.

# Interface communication
- ![800x300](Pasted%20image%2020240520133810.png)
- 

